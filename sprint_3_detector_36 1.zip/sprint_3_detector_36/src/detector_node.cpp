#include <rclcpp/rclcpp.hpp>
#include <sensor_msgs/msg/laser_scan.hpp>
#include <vector>
#include <cmath>
#include <visualization_msgs/msg/marker.hpp>

/*!
 *  \brief     marker_node Class
 *  \details
 *  This node is responsible for detecting a cylinder that is roughly 15cm in radius and displaying a marker thats meant to represent the cylinder in the 
 * environment
 * 
 *  \author    Thishanth Thirumurugan
 *  \version   1.01-1
 *  \date      2024-03-28
 *  \pre       none
 *  \bug       none reported as of 2024-03-28
 *  \warning   N/A
 */
 
class CylinderDetectionNode : public rclcpp::Node
{
public:
    CylinderDetectionNode()
    : Node("cylinder_detection_node")
    {
        // Subscriber to LaserScan data
        laser_sub_ = this->create_subscription<sensor_msgs::msg::LaserScan>(
            "/scan", 10, std::bind(&CylinderDetectionNode::laser_callback, this, std::placeholders::_1));
        marker_pub_ = this->create_publisher<visualization_msgs::msg::Marker>("/my_visualization_marker", 10);
        // publishCylinderMarker(3.0, 3.0, 0.15);

    }
 
private:
    struct Point {
        float x;
        float y;
    };

    
/**
 * Publihsing the visualisation marker to visualise the cylinder in Rviz using the published topic.
 * 
 * @param x,y,radius The x and y midpoint coordinate of the cylinder and th radius of the cylinder
 * @return void
 */
void publishCylinderMarker(float x, float y, float radius) {
        visualization_msgs::msg::Marker marker;
        marker.header.frame_id = "laser_frame";  // Set the frame ID to the laser scan's frame
        marker.header.stamp = this->now();
        marker.ns = "cylinder_marker";
        marker.id = 0;
        marker.type = visualization_msgs::msg::Marker::CYLINDER;
        marker.action = visualization_msgs::msg::Marker::ADD;

        // Set the pose of the cylinder (centered at x, y)
        marker.pose.position.x = x;
        marker.pose.position.y = y;
        marker.pose.position.z = 0.0;  // Assuming the cylinder is standing vertically
        marker.pose.orientation.x = 0.0;
        marker.pose.orientation.y = 0.0;
        marker.pose.orientation.z = 0.0;
        marker.pose.orientation.w = 1.0;

        // Set the scale of the cylinder (diameter along x and y, height along z)
        marker.scale.x = radius * 2.0;  // Diameter along x
        marker.scale.y = radius * 2.0;  // Diameter along y
        marker.scale.z = 3.0;           // Height of the cylinder

        // Set the color (e.g., green cylinder)
        marker.color.r = 0.0f;
        marker.color.g = 1.0f;
        marker.color.b = 0.0f;
        marker.color.a = 1.0f;  // Fully opaque

        // Publish the marker
        marker_pub_->publish(marker);
    }

/**
 * @brief Laser callback functon that callsback for the laserscan topic.
 * 
 * @param msg The msg of the laserscan with information about all of the laserscan data
 * @return void
 */
void laser_callback(const sensor_msgs::msg::LaserScan::SharedPtr msg)
    {
        // Vector to store points
        std::vector<Point> points;
        int num_points = msg->ranges.size();
        // Loop through laser scan data and convert to Cartesian coordinates
        for (int i = 0; i < num_points; ++i)
        {
            float angle = msg->angle_min + i * msg->angle_increment;
            float distance = msg->ranges[i];
 
            // Ignore invalid points (infinity or NaN)
            if (std::isinf(distance) || std::isnan(distance)) continue;
 
            // Convert polar coordinates to Cartesian
            Point point;
            point.x = distance * cos(angle);  // x-coordinate
            point.y = distance * sin(angle);  // y-coordinate
 
            points.push_back(point);
        }
 
        // Cluster the points to find groups that might represent an object
        auto clusters = cluster_points(points);
 
        // Check each cluster for cylindrical shape
        for (const auto& cluster : clusters)
        {
            if (is_cylindrical(cluster))
            {
                // Calculate and log the midpoint of the cylinder
                Point midpoint = calculate_midpoint(cluster);
                RCLCPP_INFO(this->get_logger(), "Cylinder detected! Midpoint (x = %.2f, y = %.2f)", midpoint.x, midpoint.y);
                publishCylinderMarker(midpoint.x, midpoint.y, 0.15);
            }
            else
            {
                RCLCPP_WARN(this->get_logger(), "No cylinder detected.");
            }
        }
    }
 
/**
 * @brief Used to cluster points. 
 * 
 * @param cluster The cluster of points to check.
 * @return true If the cluster forms a cylindrical shape. False if it is not
 */
std::vector<std::vector<Point>> cluster_points(const std::vector<Point>& points)
    {
        std::vector<std::vector<Point>> clusters;
        std::vector<Point> current_cluster;
 
        float distance_threshold = 0.1;  // Adjust this based on the scale of your laser scan data
 
        for (size_t i = 1; i < points.size(); ++i)
        {
            // Calculate distance between consecutive points
            float distance = std::sqrt(std::pow(points[i].x - points[i - 1].x, 2) +
                                       std::pow(points[i].y - points[i - 1].y, 2));
 
            if (distance < distance_threshold)
            {
                current_cluster.push_back(points[i]);
            }
            else
            {
                if (!current_cluster.empty())
                {
                    clusters.push_back(current_cluster);
                    current_cluster.clear();
                }
            }
        }
 
        if (!current_cluster.empty())
        {
            clusters.push_back(current_cluster);
        }
 
        return clusters;
    }
 
/**
 * @brief Helper function to check if a cluster forms a cylindrical shape (a circular arc).
 * 
 * @param cluster The cluster of points to check.
 * @return true If the cluster forms a cylindrical shape. False if it is not
 */
bool is_cylindrical(const std::vector<Point>& cluster)
    {
        if (cluster.size() < 3) return false;  // Too few points to form a cylinder
 
        // Calculate the centroid of the cluster
        Point centroid{0.0, 0.0};
        for (const auto& point : cluster)
        {
            centroid.x += point.x;
            centroid.y += point.y;
        }
        centroid.x /= cluster.size();
        centroid.y /= cluster.size();
 
        // Calculate the average radius
        float avg_radius = 0.0;
        for (const auto& point : cluster)
        {
            float distance = std::sqrt(std::pow(point.x - centroid.x, 2) + std::pow(point.y - centroid.y, 2));
            avg_radius += distance;
        }
        avg_radius /= cluster.size();
 
        // Check the variance of the distances from the centroid
        float variance = 0.0;
        for (const auto& point : cluster)
        {
            float distance = std::sqrt(std::pow(point.x - centroid.x, 2) + std::pow(point.y - centroid.y, 2));
            variance += std::pow(distance - avg_radius, 2);
        }
        variance /= cluster.size();
 
        // Set a threshold for the variance to ensure the points are roughly circular
        const float variance_threshold = 0.02;
 
        // Updated variance threshold and cylinder size
        const float min_cylinder_radius = 0.01; ///< Minimum cylinder radius (10 cm)
        const float max_cylinder_radius = 0.15; ///< Maximum cylinder radius (15 cm)

 
        return (avg_radius >= min_cylinder_radius && avg_radius <= max_cylinder_radius) && (variance < variance_threshold);
    }
    
/**
 * @brief Calculates the mindpoint of the cluster. Used for to figure out the midpoint of the cylinder
 * 
 * @param cluster The cluster of points to check.
 * @return Midpoint point of the cylinder
 */
// Helper function to calculate the midpoint of a cluster
Point calculate_midpoint(const std::vector<Point>& cluster)
    {
        Point midpoint{0.0, 0.0};
        for (const auto& point : cluster)
        {
            midpoint.x += point.x;
            midpoint.y += point.y;
        }
 
        midpoint.x /= cluster.size();
        midpoint.y /= cluster.size();
 
        return midpoint;
    }
 
    rclcpp::Subscription<sensor_msgs::msg::LaserScan>::SharedPtr laser_sub_;
    rclcpp::Publisher<visualization_msgs::msg::Marker>::SharedPtr marker_pub_;
};
 
int main(int argc, char *argv[])
{
    rclcpp::init(argc, argv);
    auto node = std::make_shared<CylinderDetectionNode>();
    rclcpp::spin(node);
    rclcpp::shutdown();
    return 0;
}